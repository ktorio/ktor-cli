package com.example

import java.io.File

fun main() {
    File("TestOutput.txt")
        .printWriter()
        .use {
            it.println("Hello, world!")
        }

}
